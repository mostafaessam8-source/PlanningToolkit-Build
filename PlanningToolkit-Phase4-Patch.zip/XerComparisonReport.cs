using PlanningToolkit.Core.Xer;

namespace PlanningToolkit.Excel.Excel;

internal static class XerComparisonReport
{
    private const int HeaderRow = 5;
    private const int FirstDataRow = 6;

    public static (int Activities, int Delayed, int Added, int Deleted, double FinishVariance) Create(dynamic application, string baselinePath, string updatePath)
    {
        var baselineDocument = XerParser.Parse(baselinePath);
        var updateDocument = XerParser.Parse(updatePath);
        EnsureValid(baselineDocument, "Baseline");
        EnsureValid(updateDocument, "Update");
        var hours = AppServices.CurrentSettings.WorkingHoursPerDay;
        var baseline = XerScheduleBuilder.Build(baselineDocument, hours);
        var update = XerScheduleBuilder.Build(updateDocument, hours);
        var comparison = XerScheduleComparer.Compare(baseline, update);

        dynamic workbook = application.Workbooks.Add();
        dynamic summary = workbook.Worksheets[1];
        summary.Name = "Comparison Summary";
        WriteSummary(summary, baselinePath, updatePath, comparison);
        dynamic details = workbook.Worksheets.Add(After: summary);
        details.Name = "Activity Comparison";
        WriteDetails(details, comparison.Activities);
        dynamic delayed = workbook.Worksheets.Add(After: details);
        delayed.Name = "Delayed Activities";
        WriteDetails(delayed, comparison.Activities.Where(item => item.FinishVarianceDays > 0.001 || item.UpdateCritical).ToList());
        summary.Activate();
        return (comparison.Activities.Count, comparison.DelayedCount, comparison.AddedCount, comparison.DeletedCount, comparison.ProjectFinishVarianceDays);
    }

    private static void EnsureValid(XerDocument document, string label)
    {
        var result = XerValidator.Validate(document);
        if (!result.IsValid)
            throw new InvalidOperationException($"{label} XER validation found {result.ErrorCount:N0} error(s). Validate the file first.");
    }

    private static void WriteSummary(dynamic sheet, string baselinePath, string updatePath, XerScheduleComparison comparison)
    {
        var values = new object?[16, 4];
        values[0, 0] = "Planning Toolkit — Baseline vs Update Comparison";
        values[2, 0] = "Baseline file";
        values[2, 1] = baselinePath;
        values[3, 0] = "Update file";
        values[3, 1] = updatePath;
        values[5, 0] = "Metric";
        values[5, 1] = "Baseline";
        values[5, 2] = "Update";
        values[5, 3] = "Variance / Count";
        values[6, 0] = "Project";
        values[6, 1] = comparison.Baseline.ProjectName;
        values[6, 2] = comparison.Update.ProjectName;
        values[7, 0] = "Data Date";
        values[7, 1] = comparison.Baseline.DataDate?.ToOADate();
        values[7, 2] = comparison.Update.DataDate?.ToOADate();
        values[8, 0] = "Project Finish";
        values[8, 1] = comparison.BaselineProjectFinish?.ToOADate();
        values[8, 2] = comparison.UpdateProjectFinish?.ToOADate();
        values[8, 3] = comparison.ProjectFinishVarianceDays;
        values[9, 0] = "Activities";
        values[9, 1] = comparison.Baseline.Activities.Count;
        values[9, 2] = comparison.Update.Activities.Count;
        values[10, 0] = "Delayed activities";
        values[10, 3] = comparison.DelayedCount;
        values[11, 0] = "Added activities";
        values[11, 3] = comparison.AddedCount;
        values[12, 0] = "Deleted activities";
        values[12, 3] = comparison.DeletedCount;
        values[13, 0] = "Current critical activities";
        values[13, 3] = comparison.CriticalCount;
        values[15, 0] = comparison.ProjectFinishVarianceDays > 0
            ? $"Update finish is {comparison.ProjectFinishVarianceDays:N1} calendar day(s) later than baseline."
            : comparison.ProjectFinishVarianceDays < 0
                ? $"Update finish is {Math.Abs(comparison.ProjectFinishVarianceDays):N1} calendar day(s) earlier than baseline."
                : "Update project finish matches baseline.";

        dynamic target = sheet.Cells[1, 1].Resize[16, 4];
        target.Value2 = values;
        sheet.Range["A1:D1"].Merge();
        sheet.Range["A1:D1"].Font.Bold = true;
        sheet.Range["A1:D1"].Font.Size = 16;
        sheet.Range["A6:D6"].Font.Bold = true;
        sheet.Range["A6:D6"].Interior.Color = 0x73461F;
        sheet.Range["A6:D6"].Font.Color = 0xFFFFFF;
        sheet.Range["B8:C9"].NumberFormat = "dd-mmm-yyyy";
        sheet.Range["D9"].NumberFormat = "0.0 \"days\"";
        sheet.Range["A16:D16"].Merge();
        sheet.Range["A16:D16"].Font.Bold = true;
        sheet.Range["A16:D16"].Interior.Color = comparison.ProjectFinishVarianceDays > 0 ? 0xCEC7FF : 0xD9EAD3;
        sheet.Columns[1].ColumnWidth = 32;
        sheet.Columns[2].ColumnWidth = 55;
        sheet.Columns[3].ColumnWidth = 28;
        sheet.Columns[4].ColumnWidth = 20;
    }

    private static void WriteDetails(dynamic sheet, IReadOnlyList<XerActivityComparison> activities)
    {
        string[] headers = ["Change", "WBS Path", "Activity ID", "Activity Name", "Baseline Status", "Update Status", "Baseline Start", "Update Start", "Start Variance", "Baseline Finish", "Update Finish", "Finish Variance", "Baseline Duration", "Update Duration", "Duration Variance", "Baseline Float", "Update Float", "Float Variance", "Update %", "Baseline Critical", "Update Critical", "Assessment"];
        var values = new object?[activities.Count + 1, headers.Length];
        for (var column = 0; column < headers.Length; column++) values[0, column] = headers[column];
        for (var index = 0; index < activities.Count; index++)
        {
            var item = activities[index];
            values[index + 1, 0] = item.ChangeType.ToString();
            values[index + 1, 1] = item.WbsPath;
            values[index + 1, 2] = item.ActivityCode;
            values[index + 1, 3] = item.ActivityName;
            values[index + 1, 4] = item.BaselineStatus;
            values[index + 1, 5] = item.UpdateStatus;
            values[index + 1, 6] = item.BaselineStart?.ToOADate();
            values[index + 1, 7] = item.UpdateStart?.ToOADate();
            values[index + 1, 8] = item.StartVarianceDays;
            values[index + 1, 9] = item.BaselineFinish?.ToOADate();
            values[index + 1, 10] = item.UpdateFinish?.ToOADate();
            values[index + 1, 11] = item.FinishVarianceDays;
            values[index + 1, 12] = item.BaselineDurationDays;
            values[index + 1, 13] = item.UpdateDurationDays;
            values[index + 1, 14] = item.DurationVarianceDays;
            values[index + 1, 15] = item.BaselineFloatDays;
            values[index + 1, 16] = item.UpdateFloatDays;
            values[index + 1, 17] = item.FloatVarianceDays;
            values[index + 1, 18] = item.UpdatePercentComplete;
            values[index + 1, 19] = item.BaselineCritical ? "Yes" : string.Empty;
            values[index + 1, 20] = item.UpdateCritical ? "Yes" : string.Empty;
            values[index + 1, 21] = Assess(item);
        }
        dynamic target = sheet.Cells[HeaderRow, 1].Resize[activities.Count + 1, headers.Length];
        target.Value2 = values;
        sheet.Range[$"A{HeaderRow}:V{HeaderRow}"].Font.Bold = true;
        sheet.Range[$"A{HeaderRow}:V{HeaderRow}"].Interior.Color = 0x73461F;
        sheet.Range[$"A{HeaderRow}:V{HeaderRow}"].Font.Color = 0xFFFFFF;
        if (activities.Count > 0)
        {
            sheet.Range[$"G{FirstDataRow}:H{FirstDataRow + activities.Count - 1}"].NumberFormat = "dd-mmm-yyyy";
            sheet.Range[$"J{FirstDataRow}:K{FirstDataRow + activities.Count - 1}"].NumberFormat = "dd-mmm-yyyy";
            sheet.Range[$"I{FirstDataRow}:R{FirstDataRow + activities.Count - 1}"].NumberFormat = "0.0";
            sheet.Range[$"S{FirstDataRow}:S{FirstDataRow + activities.Count - 1}"].NumberFormat = "0.0%";
        }
        for (var index = 0; index < activities.Count; index++)
        {
            var excelRow = FirstDataRow + index;
            var color = activities[index].ChangeType switch
            {
                XerActivityChangeType.Added => 0xD9EAD3,
                XerActivityChangeType.Deleted => 0xD9D9D9,
                _ when activities[index].FinishVarianceDays > 0.001 => 0xD6E4FF,
                _ => 0xFFFFFF
            };
            sheet.Range[$"A{excelRow}:V{excelRow}"].Interior.Color = color;
            if (activities[index].UpdateCritical) sheet.Range[$"A{excelRow}:V{excelRow}"].Font.Color = 0x0000C0;
        }
        sheet.Rows[HeaderRow].AutoFilter();
        sheet.Columns[1].ColumnWidth = 12;
        sheet.Columns[2].ColumnWidth = 25;
        sheet.Columns[3].ColumnWidth = 16;
        sheet.Columns[4].ColumnWidth = 42;
        sheet.Columns[5].Resize[1, 18].ColumnWidth = 14;
        sheet.Columns[22].ColumnWidth = 24;
        sheet.Application.ActiveWindow.SplitRow = HeaderRow;
        sheet.Application.ActiveWindow.FreezePanes = true;
    }

    private static string Assess(XerActivityComparison item)
    {
        if (item.ChangeType == XerActivityChangeType.Added) return "Added in update";
        if (item.ChangeType == XerActivityChangeType.Deleted) return "Deleted from update";
        if (!item.BaselineCritical && item.UpdateCritical) return "Newly critical";
        if (item.FinishVarianceDays > 0.001) return $"Delayed {item.FinishVarianceDays:N1} day(s)";
        if (item.FinishVarianceDays < -0.001) return $"Earlier {Math.Abs(item.FinishVarianceDays):N1} day(s)";
        if (item.FloatVarianceDays < -0.001) return "Float reduced";
        return item.ChangeType == XerActivityChangeType.Unchanged ? "No schedule change" : "Changed";
    }
}
