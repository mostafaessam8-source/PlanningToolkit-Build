using System.Globalization;
using PlanningToolkit.Core;
using PlanningToolkit.Core.Text;
using PlanningToolkit.Core.Xer;
using PlanningToolkit.Infrastructure.Logging;
using PlanningToolkit.Infrastructure.Settings;

namespace PlanningToolkit.Tests;

internal static class Program
{
    private static int Main()
    {
        var tests = new (string Name, Action Test)[]
        {
            ("TrimWhitespace", TrimWhitespace),
            ("RemoveNonPrintingCharacters", RemoveNonPrintingCharacters),
            ("CaseConversions", CaseConversions),
            ("SentenceCase", SentenceCase),
            ("KnownDateFormats", KnownDateFormats),
            ("InvalidDate", InvalidDate),
            ("DefaultSettingsAreValid", DefaultSettingsAreValid),
            ("InvalidSettingsAreRejected", InvalidSettingsAreRejected),
            ("SettingsRoundTrip", SettingsRoundTrip),
            ("InvalidJsonFallsBackToDefaults", InvalidJsonFallsBackToDefaults),
            ("ParseXerTables", ParseXerTables),
            ("ValidateGoodXer", ValidateGoodXer),
            ("DetectXerColumnMismatch", DetectXerColumnMismatch),
            ("DetectDuplicateTaskId", DetectDuplicateTaskId),
            ("BuildScheduleModel", BuildScheduleModel),
            ("DetectCriticalActivity", DetectCriticalActivity),
            ("CompareBaselineAndUpdate", CompareBaselineAndUpdate),
            ("DetectAddedAndDeletedActivities", DetectAddedAndDeletedActivities)
        };

        var failures = 0;
        Console.WriteLine($"Running {tests.Length} Planning Toolkit Phase 2 tests...");

        foreach (var (name, test) in tests)
        {
            try
            {
                test();
                Console.WriteLine($"PASS {name}");
            }
            catch (Exception exception)
            {
                failures++;
                Console.Error.WriteLine($"FAIL {name}: {exception.Message}");
            }
        }

        Console.WriteLine(failures == 0
            ? $"All {tests.Length} tests passed."
            : $"{failures} of {tests.Length} tests failed.");
        return failures == 0 ? 0 : 1;
    }

    private static void TrimWhitespace() => Equal(
        "Alpha Beta",
        TextTransforms.TrimWhitespace("  Alpha\t\tBeta  "));

    private static void RemoveNonPrintingCharacters() => Equal(
        "AB\tC",
        TextTransforms.RemoveNonPrintingCharacters("A\u0001B\tC"));

    private static void CaseConversions()
    {
        var culture = CultureInfo.GetCultureInfo("en-US");
        Equal("SCHEDULE UPDATE", TextTransforms.ToUpper("Schedule Update", culture));
        Equal("schedule update", TextTransforms.ToLower("Schedule Update", culture));
        Equal("Schedule Update", TextTransforms.ToProperCase("sCHEDULE uPDATE", culture));
    }

    private static void SentenceCase() => Equal(
        "First sentence. Second sentence! Third?",
        TextTransforms.ToSentenceCase("FIRST SENTENCE. SECOND SENTENCE! THIRD?", CultureInfo.GetCultureInfo("en-US")));

    private static void KnownDateFormats()
    {
        True(DateParser.TryParse("20-Jul-2026", out var first));
        Equal(new DateTime(2026, 7, 20), first.Date);
        True(DateParser.TryParse("2026-07-20", out var second));
        Equal(new DateTime(2026, 7, 20), second.Date);
    }

    private static void InvalidDate() => False(DateParser.TryParse("not-a-date", out _));

    private static void DefaultSettingsAreValid() => Equal(0, new AppSettings().Validate().Count);

    private static void InvalidSettingsAreRejected()
    {
        var settings = new AppSettings { WorkingDaysPerWeek = 9, CurrencyCode = "RIYAL" };
        True(settings.Validate().Count >= 2);
    }

    private static void SettingsRoundTrip()
    {
        var directory = CreateTemporaryDirectory();
        try
        {
            var path = Path.Combine(directory, "settings.json");
            var store = new JsonSettingsStore(path);
            store.Save(new AppSettings { CurrencyCode = "USD", WorkingHoursPerDay = 9 });
            var loaded = store.Load();
            Equal("USD", loaded.CurrencyCode);
            Equal(9d, loaded.WorkingHoursPerDay);
        }
        finally
        {
            Directory.Delete(directory, recursive: true);
        }
    }

    private static void InvalidJsonFallsBackToDefaults()
    {
        var directory = CreateTemporaryDirectory();
        try
        {
            var path = Path.Combine(directory, "settings.json");
            File.WriteAllText(path, "{ invalid json }");
            var logger = new FileAppLogger(Path.Combine(directory, "logs"));
            var loaded = new JsonSettingsStore(path, logger).Load();
            Equal("SAR", loaded.CurrencyCode);
        }
        finally
        {
            Directory.Delete(directory, recursive: true);
        }
    }

    private static void ParseXerTables()
    {
        var document = ParseSample();
        Equal(3, document.Tables.Count);
        Equal(1, document.FindTable("PROJECT")!.Rows.Count);
        Equal("Activity A", document.FindTable("TASK")!.Rows[0].Values[2]);
    }

    private static void ValidateGoodXer()
    {
        var result = XerValidator.Validate(ParseSample());
        True(result.IsValid);
        Equal(0, result.ErrorCount);
    }

    private static void DetectXerColumnMismatch()
    {
        var text = "ERMHDR\t8.4\n%T\tTASK\n%F\ttask_id\ttask_name\n%R\t1\n%E\n";
        var result = XerValidator.Validate(XerParser.Parse(new StringReader(text)));
        True(result.Issues.Any(issue => issue.Code == "COLUMN_COUNT"));
    }

    private static void DetectDuplicateTaskId()
    {
        var text = "ERMHDR\t8.4\n%T\tTASK\n%F\ttask_id\ttask_name\n%R\t1\tA\n%R\t1\tB\n%E\n";
        var result = XerValidator.Validate(XerParser.Parse(new StringReader(text)));
        True(result.Issues.Any(issue => issue.Code == "ID_DUPLICATE"));
    }

    private static XerDocument ParseSample()
    {
        const string text =
            "ERMHDR\t8.4\n" +
            "%T\tPROJECT\n%F\tproj_id\tproj_short_name\n%R\t10\tDemo\n" +
            "%T\tPROJWBS\n%F\twbs_id\tproj_id\twbs_name\n%R\t20\t10\tRoot\n" +
            "%T\tTASK\n%F\ttask_id\tproj_id\ttask_name\n%R\t30\t10\tActivity A\n%E\n";
        return XerParser.Parse(new StringReader(text));
    }

    private static void BuildScheduleModel()
    {
        var document = XerParser.Parse(new StringReader(ScheduleSample));
        var schedule = XerScheduleBuilder.Build(document);
        Equal("Demo Project", schedule.ProjectName);
        Equal(new DateTime(2026, 7, 20), schedule.DataDate!.Value.Date);
        Equal(2, schedule.WbsItems.Count);
        Equal(2, schedule.Activities.Count);
        Equal("In Progress", schedule.Activities[0].Status);
        Equal(10d, schedule.Activities[0].OriginalDurationDays);
    }

    private static void DetectCriticalActivity()
    {
        var schedule = XerScheduleBuilder.Build(XerParser.Parse(new StringReader(ScheduleSample)));
        True(schedule.Activities.Single(activity => activity.Code == "A1000").IsCritical);
        False(schedule.Activities.Single(activity => activity.Code == "A1010").IsCritical);
    }

    private static void CompareBaselineAndUpdate()
    {
        var baseline = new XerSchedule();
        baseline.Activities.Add(Activity("1", "A1000", new DateTime(2026, 7, 10), false));
        var update = new XerSchedule();
        update.Activities.Add(Activity("1", "A1000", new DateTime(2026, 7, 15), true));
        var result = XerScheduleComparer.Compare(baseline, update);
        Equal(1, result.Activities.Count);
        Equal(5d, result.Activities[0].FinishVarianceDays);
        Equal("Newly critical", result.Activities[0].UpdateCritical && !result.Activities[0].BaselineCritical ? "Newly critical" : string.Empty);
    }

    private static void DetectAddedAndDeletedActivities()
    {
        var baseline = new XerSchedule();
        baseline.Activities.Add(Activity("1", "DELETED", new DateTime(2026, 7, 10), false));
        var update = new XerSchedule();
        update.Activities.Add(Activity("2", "ADDED", new DateTime(2026, 7, 10), false));
        var result = XerScheduleComparer.Compare(baseline, update);
        Equal(1, result.AddedCount);
        Equal(1, result.DeletedCount);
    }

    private static XerScheduleActivity Activity(string id, string code, DateTime finish, bool critical) =>
        new(id, code, code, null, "Not Started", 5, 5, finish.AddDays(-5), finish, 0, critical ? 0 : 5, critical, string.Empty, string.Empty);

    private const string ScheduleSample =
        "ERMHDR\t8.4\n" +
        "%T\tPROJECT\n%F\tproj_id\tproj_short_name\tlast_recalc_date\n%R\t10\tDemo Project\t2026-07-20 08:00\n" +
        "%T\tPROJWBS\n%F\twbs_id\tparent_wbs_id\twbs_short_name\twbs_name\tseq_num\n%R\t20\t\t1\tProject\t1\n%R\t21\t20\t1.1\tConstruction\t2\n" +
        "%T\tTASK\n%F\ttask_id\ttask_code\ttask_name\twbs_id\tstatus_code\ttarget_drtn_hr_cnt\tremain_drtn_hr_cnt\tphys_complete_pct\tearly_start_date\tearly_end_date\ttotal_float_hr_cnt\n" +
        "%R\t30\tA1000\tCritical Work\t21\tTK_Active\t80\t40\t50\t2026-07-20 08:00\t2026-07-30 17:00\t0\n" +
        "%R\t31\tA1010\tNoncritical Work\t21\tTK_NotStart\t40\t40\t0\t2026-07-31 08:00\t2026-08-05 17:00\t24\n%E\n";

    private static string CreateTemporaryDirectory()
    {
        var path = Path.Combine(Path.GetTempPath(), "PlanningToolkitTests", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(path);
        return path;
    }

    private static void True(bool value)
    {
        if (!value)
            throw new InvalidOperationException("Expected true but received false.");
    }

    private static void False(bool value) => True(!value);

    private static void Equal<T>(T expected, T actual)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new InvalidOperationException($"Expected '{expected}' but received '{actual}'.");
    }
}
