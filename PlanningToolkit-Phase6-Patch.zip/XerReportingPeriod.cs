namespace PlanningToolkit.Core.Xer;

public enum XerReportingPeriod
{
    Weekly,
    Monthly
}

public static class XerReportingPeriods
{
    public static string DisplayName(XerReportingPeriod period) => period == XerReportingPeriod.Monthly ? "Monthly" : "Weekly";

    public static DateTime AlignStart(DateTime date, XerReportingPeriod period)
    {
        date = date.Date;
        if (period == XerReportingPeriod.Monthly)
            return new DateTime(date.Year, date.Month, 1);
        return date.AddDays(-(7 + (int)date.DayOfWeek - (int)DayOfWeek.Monday) % 7);
    }

    public static DateTime Next(DateTime periodStart, XerReportingPeriod period) =>
        period == XerReportingPeriod.Monthly ? periodStart.AddMonths(1) : periodStart.AddDays(7);

    public static DateTime End(DateTime periodStart, XerReportingPeriod period) =>
        Next(periodStart, period).AddDays(-1);
}
