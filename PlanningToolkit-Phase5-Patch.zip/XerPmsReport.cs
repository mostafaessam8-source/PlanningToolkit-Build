using PlanningToolkit.Core.Xer;

namespace PlanningToolkit.Excel.Excel;

internal static class XerPmsReport
{
    public static (double Planned, double Actual, double Spi, int LookAhead, int Critical) Create(dynamic application, string baselinePath, string updatePath)
    {
        var baselineDocument = XerParser.Parse(baselinePath);
        var updateDocument = XerParser.Parse(updatePath);
        EnsureValid(baselineDocument, "Baseline");
        EnsureValid(updateDocument, "Update");
        var hours = AppServices.CurrentSettings.WorkingHoursPerDay;
        var analysis = XerProgressAnalyzer.Analyze(XerScheduleBuilder.Build(baselineDocument, hours), XerScheduleBuilder.Build(updateDocument, hours));

        dynamic workbook = application.Workbooks.Add();
        dynamic dashboard = workbook.Worksheets[1];
        dashboard.Name = "Dashboard";
        dynamic curve = workbook.Worksheets.Add(After: dashboard);
        curve.Name = "S-Curve Data";
        dynamic lookAhead = workbook.Worksheets.Add(After: curve);
        lookAhead.Name = "2-Week Look Ahead";
        dynamic critical = workbook.Worksheets.Add(After: lookAhead);
        critical.Name = "Critical Path";
        dynamic wbs = workbook.Worksheets.Add(After: critical);
        wbs.Name = "WBS Progress";

        WriteCurve(curve, analysis);
        WriteActivityList(lookAhead, "Two-Week Look Ahead", analysis.TwoWeekLookAhead);
        WriteActivityList(critical, "Critical Path", analysis.CriticalPath);
        WriteWbsProgress(wbs, analysis.Comparison.Activities);
        WriteDashboard(dashboard, curve, analysis);
        dashboard.Activate();
        return (analysis.PlannedPercent, analysis.ActualPercent, analysis.Spi, analysis.TwoWeekLookAhead.Count, analysis.CriticalPath.Count);
    }

    private static void EnsureValid(XerDocument document, string label)
    {
        var result = XerValidator.Validate(document);
        if (!result.IsValid) throw new InvalidOperationException($"{label} XER validation found {result.ErrorCount:N0} error(s). Validate the file first.");
    }

    private static void WriteDashboard(dynamic sheet, dynamic curveSheet, XerProgressAnalysis analysis)
    {
        sheet.Cells[1, 1] = "Planning Toolkit — Project Controls Dashboard";
        sheet.Range["A1:F1"].Merge();
        sheet.Range["A1:F1"].Font.Bold = true;
        sheet.Range["A1:F1"].Font.Size = 18;
        sheet.Range["A1:F1"].Interior.Color = 0x73461F;
        sheet.Range["A1:F1"].Font.Color = 0xFFFFFF;
        sheet.Cells[2, 1] = "Project";
        sheet.Cells[2, 2] = analysis.Comparison.Update.ProjectName;
        sheet.Cells[3, 1] = "Data Date";
        sheet.Cells[3, 2] = analysis.DataDate.ToOADate();
        sheet.Cells[3, 2].NumberFormat = "dd-mmm-yyyy";

        string[] kpiNames = ["Planned %", "Actual %", "Variance", "SPI", "Finish Variance", "Critical Activities", "2-Week Look Ahead", "Completed", "In Progress", "Not Started"];
        object[] kpiValues = [analysis.PlannedPercent, analysis.ActualPercent, analysis.ProgressVariance, analysis.Spi, analysis.Comparison.ProjectFinishVarianceDays, analysis.CriticalPath.Count, analysis.TwoWeekLookAhead.Count, analysis.CompletedCount, analysis.InProgressCount, analysis.NotStartedCount];
        for (var index = 0; index < kpiNames.Length; index++)
        {
            var column = 1 + index % 5;
            var row = 5 + (index / 5) * 3;
            sheet.Cells[row, column] = kpiNames[index];
            sheet.Cells[row + 1, column] = kpiValues[index];
            sheet.Cells[row, column].Font.Bold = true;
            sheet.Cells[row, column].Interior.Color = 0xDDEBF7;
            sheet.Cells[row + 1, column].Font.Bold = true;
            sheet.Cells[row + 1, column].Font.Size = 16;
        }
        sheet.Range["A6:C6"].NumberFormat = "0.0%";
        sheet.Range["D6"].NumberFormat = "0.00";
        sheet.Range["E6"].NumberFormat = "0.0 \"days\"";
        sheet.Cells[11, 8] = "Status";
        sheet.Cells[11, 9] = "Count";
        sheet.Cells[12, 8] = "Completed";
        sheet.Cells[12, 9] = analysis.CompletedCount;
        sheet.Cells[13, 8] = "In Progress";
        sheet.Cells[13, 9] = analysis.InProgressCount;
        sheet.Cells[14, 8] = "Not Started";
        sheet.Cells[14, 9] = analysis.NotStartedCount;
        sheet.Columns[1].Resize[1, 5].ColumnWidth = 18;
        sheet.Columns[2].ColumnWidth = 28;
        TryCreateCharts(sheet, curveSheet, analysis.Curve.Count);
    }

    private static void TryCreateCharts(dynamic dashboard, dynamic curveSheet, int pointCount)
    {
        try
        {
            dynamic curveObject = dashboard.ChartObjects().Add(20, 230, 820, 330);
            dynamic curveChart = curveObject.Chart;
            curveChart.ChartType = 4;
            curveChart.SetSourceData(curveSheet.Range[$"A4:D{4 + pointCount}"]);
            curveChart.HasTitle = true;
            curveChart.ChartTitle.Text = "S-Curve — Planned vs Actual vs Forecast";
            curveChart.HasLegend = true;
            dynamic statusObject = dashboard.ChartObjects().Add(860, 230, 360, 330);
            dynamic statusChart = statusObject.Chart;
            statusChart.ChartType = -4120;
            statusChart.SetSourceData(dashboard.Range["H11:I14"]);
            statusChart.HasTitle = true;
            statusChart.ChartTitle.Text = "Activity Status";
        }
        catch (Exception exception)
        {
            AppServices.Logger.Error("Dashboard charts could not be created; data sheets remain available.", exception);
        }
    }

    private static void WriteCurve(dynamic sheet, XerProgressAnalysis analysis)
    {
        var values = new object?[analysis.Curve.Count + 1, 4];
        values[0, 0] = "Date";
        values[0, 1] = "Baseline Planned";
        values[0, 2] = "Estimated Actual";
        values[0, 3] = "Current Forecast";
        for (var index = 0; index < analysis.Curve.Count; index++)
        {
            var point = analysis.Curve[index];
            values[index + 1, 0] = point.Date.ToOADate();
            values[index + 1, 1] = point.Planned;
            values[index + 1, 2] = point.Actual;
            values[index + 1, 3] = point.Forecast;
        }
        sheet.Cells[1, 1] = "S-Curve Data (duration weighted)";
        sheet.Cells[2, 1] = "Actual history is estimated from current earned progress; use period data for certified historical curves.";
        dynamic target = sheet.Cells[4, 1].Resize[analysis.Curve.Count + 1, 4];
        target.Value2 = values;
        sheet.Range["A4:D4"].Font.Bold = true;
        sheet.Range["A4:D4"].Interior.Color = 0x73461F;
        sheet.Range["A4:D4"].Font.Color = 0xFFFFFF;
        if (analysis.Curve.Count > 0)
        {
            sheet.Range[$"A5:A{4 + analysis.Curve.Count}"].NumberFormat = "dd-mmm-yyyy";
            sheet.Range[$"B5:D{4 + analysis.Curve.Count}"].NumberFormat = "0.0%";
        }
        sheet.Columns[1].ColumnWidth = 16;
        sheet.Columns[2].Resize[1, 3].ColumnWidth = 20;
    }

    private static void WriteActivityList(dynamic sheet, string title, IReadOnlyList<XerActivityComparison> activities)
    {
        string[] headers = ["WBS Path", "Activity ID", "Activity Name", "Status", "Start", "Finish", "Planned %", "Actual %", "Variance", "Total Float", "Critical", "Assessment"];
        var values = new object?[activities.Count + 1, headers.Length];
        for (var column = 0; column < headers.Length; column++) values[0, column] = headers[column];
        for (var index = 0; index < activities.Count; index++)
        {
            var item = activities[index];
            values[index + 1, 0] = item.WbsPath;
            values[index + 1, 1] = item.ActivityCode;
            values[index + 1, 2] = item.ActivityName;
            values[index + 1, 3] = item.UpdateStatus;
            values[index + 1, 4] = item.UpdateStart?.ToOADate();
            values[index + 1, 5] = item.UpdateFinish?.ToOADate();
            values[index + 1, 6] = item.PlannedPercent;
            values[index + 1, 7] = item.ActualPercent;
            values[index + 1, 8] = item.ProgressVariance;
            values[index + 1, 9] = item.UpdateFloatDays;
            values[index + 1, 10] = item.UpdateCritical ? "Yes" : string.Empty;
            values[index + 1, 11] = item.ProgressVariance < 0 ? "Behind plan" : item.UpdateCritical ? "Critical" : "On / ahead of plan";
        }
        sheet.Cells[1, 1] = title;
        dynamic target = sheet.Cells[4, 1].Resize[activities.Count + 1, headers.Length];
        target.Value2 = values;
        sheet.Range["A4:L4"].Font.Bold = true;
        sheet.Range["A4:L4"].Interior.Color = 0x73461F;
        sheet.Range["A4:L4"].Font.Color = 0xFFFFFF;
        if (activities.Count > 0)
        {
            sheet.Range[$"E5:F{4 + activities.Count}"].NumberFormat = "dd-mmm-yyyy";
            sheet.Range[$"G5:I{4 + activities.Count}"].NumberFormat = "0.0%";
            sheet.Range[$"J5:J{4 + activities.Count}"].NumberFormat = "0.0";
        }
        sheet.Rows[4].AutoFilter();
        sheet.Columns[1].ColumnWidth = 24;
        sheet.Columns[2].ColumnWidth = 16;
        sheet.Columns[3].ColumnWidth = 44;
        sheet.Columns[4].Resize[1, 9].ColumnWidth = 14;
        sheet.Application.ActiveWindow.SplitRow = 4;
        sheet.Application.ActiveWindow.FreezePanes = true;
    }

    private static void WriteWbsProgress(dynamic sheet, IReadOnlyList<XerActivityComparison> activities)
    {
        var groups = activities.GroupBy(item => item.WbsPath, StringComparer.OrdinalIgnoreCase).OrderBy(group => group.Key, StringComparer.OrdinalIgnoreCase).ToList();
        var values = new object?[groups.Count + 1, 8];
        string[] headers = ["WBS Path", "Activities", "Planned %", "Actual %", "Variance", "Delayed", "Critical", "Finish Variance"];
        for (var column = 0; column < headers.Length; column++) values[0, column] = headers[column];
        for (var index = 0; index < groups.Count; index++)
        {
            var items = groups[index].ToList();
            var planned = Weighted(items, item => item.PlannedPercent);
            var actual = Weighted(items, item => item.ActualPercent);
            values[index + 1, 0] = groups[index].Key;
            values[index + 1, 1] = items.Count;
            values[index + 1, 2] = planned;
            values[index + 1, 3] = actual;
            values[index + 1, 4] = actual - planned;
            values[index + 1, 5] = items.Count(item => item.FinishVarianceDays > 0.001);
            values[index + 1, 6] = items.Count(item => item.UpdateCritical);
            values[index + 1, 7] = items.Select(item => item.FinishVarianceDays).DefaultIfEmpty(0d).Max();
        }
        sheet.Cells[1, 1] = "WBS Progress Summary";
        dynamic target = sheet.Cells[4, 1].Resize[groups.Count + 1, 8];
        target.Value2 = values;
        sheet.Range["A4:H4"].Font.Bold = true;
        sheet.Range["A4:H4"].Interior.Color = 0x73461F;
        sheet.Range["A4:H4"].Font.Color = 0xFFFFFF;
        if (groups.Count > 0)
        {
            sheet.Range[$"C5:E{4 + groups.Count}"].NumberFormat = "0.0%";
            sheet.Range[$"H5:H{4 + groups.Count}"].NumberFormat = "0.0";
        }
        sheet.Columns[1].ColumnWidth = 36;
        sheet.Columns[2].Resize[1, 7].ColumnWidth = 15;
        sheet.Rows[4].AutoFilter();
    }

    private static double Weighted(IReadOnlyList<XerActivityComparison> items, Func<XerActivityComparison, double> selector)
    {
        var weights = items.Select(item => Math.Max(item.BaselineDurationDays > 0 ? item.BaselineDurationDays : item.UpdateDurationDays, 0d)).ToArray();
        var total = weights.Sum();
        if (total <= 0d) return items.Count == 0 ? 0d : items.Average(selector);
        var sum = 0d;
        for (var index = 0; index < items.Count; index++) sum += selector(items[index]) * weights[index];
        return sum / total;
    }
}
